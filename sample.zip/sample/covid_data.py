#!/usr/bin/env python
# coding: utf-8

# In[6]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import csv


# In[ ]:


df = pd.read_csv(r"C:\Users\Shiny Hettiarachchi\Desktop\Python\sample\covid_19_data.csv")


# In[ ]:

df.head()

# In[ ]:




